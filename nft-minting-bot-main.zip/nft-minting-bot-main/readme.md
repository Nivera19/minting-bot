# NFT minting bot

### ❗Important❗
To get Full version of the bot join our [discord](https://discord.gg/nBwpZDP8SF) and get FREE beta key.

### 1. Installing dependencies
To install all dependencies run:
```sh 
npm install
```
### 2.Configuring:
To configure copy  **.env.example** file, change urls and values there and save as **.env** file.

### 3.Minting
To mint just simply run 

```sh
npm start
```
